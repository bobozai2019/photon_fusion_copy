"""Measure the bundled Godot addon in independent, sequential sync_lab rooms."""
import json
import re
import shutil
import socket
import statistics
import subprocess
import sys
import time
from pathlib import Path

WORK = Path(__file__).resolve().parent
EXAMPLES = WORK.parents[2]
sys.path.insert(0, str(EXAMPLES / "tools"))
from verify_sync_lab import configure, LAB

ENGINE = LAB / "runtime/godot-4.6.1/Godot_v4.6.1-stable_win64.exe"
SDK = LAB / "addons/netcode"
FIELDS = ["version", "energy", "active", "label", "offset", "trail", "tags", "sent_at"]
CELLS = [(128, 8), (1024, 1), (512, 8), (1024, 4), (1024, 8)]


def change(file, old, new):
    source = file.read_text(encoding="utf-8")
    assert source.count(old) == 1, (file, old)
    file.write_text(source.replace(old, new), encoding="utf-8")


def configure_cell(room, fields):
    configure(room, ENGINE, SDK, "Netcode", False, None)
    shutil.copy2(WORK / "meter.gd", room)
    for name in ("global", "area1", "area2"):
        change(room / f"netcode_{name}.tscn", "owner_mode = 1",
               "process_physics_priority = 1000\nowner_mode = 1")
    config = room / "netcode_orb_config.tres"
    def paths(n):
        return ", ".join(f'NodePath(":{field}")' for field in FIELDS[:n])
    if fields != 8:
        change(config, paths(8), paths(fields))
        change(config, 'limits = {NodePath(":trail"): 4, NodePath(":tags"): 4}', "limits = {}")
        orb = room / "orb.gd"
        source = orb.read_text(encoding="utf-8")
        prefix = source[:source.index("func matches(")]
        condition = "wave > 0 and version == (wave << 34) + index + 1"
        if fields == 4:
            condition += ' and is_equal_approx(energy, _energy_for(wave)) and active == ((wave + index) % 4 == 0) and label == "%d/%d" % [index, wave]'
        orb.write_text(prefix + "func matches(wave: int) -> bool:\n\treturn " + condition + "\n", encoding="utf-8")
    # Check progress via the replicated version so all schema variants use the same criterion.
    change(room / "sync_trace.gd", "elif orb.sent_at > 0 and orb.version >",
           "elif (orb.version >> 34) > 0 and orb.version >")
    script = room / "lab.gd"
    change(script, "func _ready() -> void:", """var _cost_epoch := 0
func _ready() -> void:
	for priority in [998, 999, 1001]:
		var meter := preload("res://meter.gd").new()
		meter.process_physics_priority = priority
		add_child(meter)""")
    change(script, "func _process(dt: float) -> void:", """func _process(dt: float) -> void:
	var now_ms := roundi(Time.get_unix_time_from_system() * 1000)
	if _cost_epoch > 0 and now_ms - _cost_epoch >= (11200 if _host else 10800):
		get_tree().quit()
		return
	if _cost_epoch == 0 and _round and _wave >= 60:
		var path := "res://epoch.txt"
		if _host and not FileAccess.file_exists(path):
			var f := FileAccess.open(path, FileAccess.WRITE)
			f.store_string(str(now_ms + 500))
			f.close()
		if FileAccess.file_exists(path):
			_cost_epoch = int(FileAccess.get_file_as_string(path))""")
    change(script, "\t\tif _host and _demo_check and _saw_peer:\n\t\t\t_advance_demo_aoi()", "")


def results(room, role, objects, epoch):
    log = (room / f"{role}.log").read_text(encoding="utf-8", errors="replace")
    remote = 1 if role == "host" else objects - 1
    assert f"SYNC_LAB_FIELDS {remote}/{remote}" in log and "SCRIPT ERROR" not in log, log[-1000:]
    windows = []
    trace = []
    for line in log.splitlines():
        if line.startswith("COST_CPU "):
            stamp, steps, elapsed, empty = map(int, line.split()[1:])
            if epoch + 1500 <= stamp < epoch + 9500:
                windows.append({"timestamp":stamp, "steps":steps, "elapsed_us":elapsed, "empty_us":empty})
        if line.startswith("SYNC_LAB_TRACE "):
            row = json.loads(line[len("SYNC_LAB_TRACE "):])
            if epoch + 1500 <= row["unix_ms"] < epoch + 9500:
                assert row["round"] and row["visible"] == objects and row["proxy_changes_only"] and row["aoi"] == 0
                trace.append({"advanced":sum(x["advanced"] for x in row["remote_groups"].values()),
                              "writes":row["load_writes"] + row["player_writes"], "physics_hz":row["physics_hz"]})
    assert len(windows) >= 10 and len(trace) >= 4, (len(windows), len(trace))
    assert statistics.median(row["advanced"] for row in trace) == remote, trace
    return {"node_ms":statistics.median(r["elapsed_us"]/r["steps"]/1000 for r in windows),
            "remote_verified":remote, "windows":windows, "trace":trace}


def run(objects, fields, iteration):
    room = WORK / f"n{objects}f{fields}r{iteration}"
    room.mkdir()
    configure_cell(room, fields)
    with socket.socket() as port:
        port.bind(("127.0.0.1", 0))
        endpoint = f"127.0.0.1:{port.getsockname()[1]}"
    jobs = {}
    ready = room / "ready.txt"
    try:
        for role in ("host", "guest"):
            args = [ENGINE, "--headless", "--max-fps", "60", "--path", room, "--", "--backend", "Netcode",
                    "--endpoint", endpoint, "--objects", str(objects), "--demo-check", "--trace"]
            args += ["--host", "--host-ready", ready] if role == "host" else ["--join"]
            with (room / f"{role}.log").open("wb") as log:
                jobs[role] = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
            if role == "host":
                limit = time.monotonic() + 15
                while not ready.exists() and jobs[role].poll() is None and time.monotonic() < limit:
                    time.sleep(.1)
                assert ready.read_text().strip() == "ready"
        exits = {role:job.wait(timeout=65) for role, job in jobs.items()}
        assert not any(exits.values()), exits
    finally:
        for job in jobs.values():
            if job.poll() is None:
                job.kill()
                job.wait()
    epoch = int((room/"epoch.txt").read_text())
    row = {"objects": objects, "fields": fields, "run": iteration,
           "sdk":(SDK/"build-id.txt").read_text().strip(),"exit_codes":exits}
    for role in jobs:
        row[role] = results(room, role, objects, epoch)
    (room/"result.json").write_text(json.dumps(row, indent=2))
    print(objects, fields, iteration, *(round(row[role]["node_ms"],3) for role in jobs), flush=True)


if __name__ == "__main__":
    for i in (1, 2):
        for n, f in (CELLS if i == 1 else reversed(CELLS)):
            run(n, f, i)
