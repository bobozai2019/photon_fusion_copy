import json, re, sys
from collections import Counter
from pathlib import Path
from statistics import median
from math import ceil
w=Path(__file__).resolve().parent
p=w/sys.argv[1]
epoch=int((p/'epoch.txt').read_text())
raw=json.loads((p/'frames.json').read_text())
enum=(w.parents[2].parent/'netcode/core/session/game_wire.hpp').read_text().split('enum class GameMessage')[1].split('{')[1].split('}')[0]
names={}
i=0
for part in enum.replace('\n',' ').split(','):
    pair=part.strip().split('=')
    if not pair[0]:continue
    i=int(pair[1]) if len(pair)>1 else i+1
    names[i]=pair[0].strip()
history={}
def unpack(buf):
    it=iter(buf)
    def vi():
        n=0
        for k in range(5):
            b=next(it);n|=(b&127)<<(7*k)
            if b<128:return n
        raise ValueError('varint')
    seq,anchor,size=vi(),vi(),vi()
    out=bytearray()
    for tag in it:
        if 0<tag<128:out.extend(next(it) for _ in range(tag))
        elif tag==128:
            z=vi();out+=((z>>1)^(-(z&1)&0xffffffff)).to_bytes(4,'little')
        elif tag==131:out+=bytes(vi())
        elif tag in (129,130):
            pos,n=vi(),vi()
            src=history[anchor] if tag==129 else out
            chunk=src[pos:pos+n]
            assert len(chunk)==n
            out+=chunk
        else:raise ValueError(tag)
    assert len(out)==size
    history[seq]=out
    return out
def decode_records(data):
    pos=5
    def read(n):
        nonlocal pos
        assert pos+n<=len(data)
        block=data[pos:pos+n];pos+=n
        return int.from_bytes(block,'little')
    def vi():
        value=0
        for k in range(5):
            b=read(1);value|=(b&127)<<(7*k)
            if b<128:return value
        raise ValueError('word varint')
    entries=[]
    for _ in range(data[4]):
        obj,rev,_,kind=read(4),read(4),read(4),read(1)
        mask=None
        if kind not in (2,3):
            assert kind in (1,4,5,6)
            if kind in (4,6):
                read(4);read(4*read(1))
            read(12)
            if kind in (5,6):
                i=-1;indices=[]
                for _ in range(vi()):
                    i+=vi()+1;vi();indices.append(i)
                mask='w'+','.join(map(str,indices))
            else:
                bits=read(8);assert bits<256
                mask=f'f{bits:x}'
                for i in range(8):
                    if bits&(1<<i):
                        n={1:4,2:1,4:8}.get(i)
                        if n is None: n=read(2)*(4 if i in (5,6) else 1)
                        read(n)
        entries.append((obj,rev,mask))
    assert pos==len(data)
    return entries
frames=[]
for tm,side,lane,h in raw:
    b=bytes.fromhex(h)
    typ=names.get(b[0],'unknown') if lane==1 else 'transport-control'
    records=[]
    rawlen=0
    if side=='down' and typ in ('Snapshot','CompactSnapshot'):
        body=unpack(b[17:]) if typ=='CompactSnapshot' else b[17:]
        records=decode_records(body); rawlen=len(body)+17
    elif side=='up' and typ in ('AuthorityState','AuthorityStateWords'):
        records=[(int.from_bytes(b[17:21],'little'),int.from_bytes(b[25:29],'little'),None)]
    frames.append(((tm-epoch)/1000,side,typ,len(b)+3,records,rawlen))
result={}
windows={'idle':(1,4),'energy':(6,9),'host8':(11,14),'guest8':(16,19),'bulk':(23,32)}
for stage,(a,b) in windows.items():
    stats={}
    for side in ['down','up']:
        rows=[r for r in frames if r[1]==side and a<=r[0]<b]
        state=[r for r in rows if r[2] in ('Snapshot','CompactSnapshot') and side=='down' or r[2] in ('AuthorityState','AuthorityStateWords') and side=='up']
        entries=[e for r in state for e in r[4]]
        nr=len(entries)
        distinct=len(set((o,rev) for o,rev,_ in entries))
        stats[side]={'all_Bps':round(sum(r[3] for r in rows)/(b-a),1),'state_Bps':round(sum(r[3] for r in state)/(b-a),1),'records':nr,
                     'state_B_per_record':round(sum(r[3] for r in state)/nr,2) if nr else None,
                     'distinct':distinct,'state_B_per_distinct':round(sum(r[3] for r in state)/distinct,2) if distinct else None,
                     'masks':dict(Counter(e[2] for e in entries).most_common(3)),
                     'raw_game_B_per_record':round(sum(r[5] for r in state)/nr,2) if nr and side=='down' else None,
                     'packets':dict(Counter(r[2] for r in rows))}
    for role in ('host','guest'):
        log=(p/f'{role}.log').read_text(encoding='utf-8',errors='replace')
        samples=[]
        for line in log.splitlines():
            if line.startswith('COST_CPU '):
                ms,n,us,extra=map(int,line.split()[1:])
                if a+.5<=(ms-epoch)/1000<b:
                    samples.append((us/n,extra/n))
        assert samples
        times=[x[0] for x in samples]
        stats[role]={'sync_us_per_step':round(median(times),2),'empty_us_per_step':round(median(x[1] for x in samples),2),'windows':len(samples)}
        trace=[json.loads(l[15:]) for l in log.splitlines() if l.startswith('SYNC_LAB_TRACE ')]
        trace=[t for t in trace if a<(t['unix_ms']-epoch)/1000<b and t['round']]
        if trace:
            stats[role]['visible']=min(t['visible'] for t in trace)
            stats[role]['median_physics_hz']=round(median(t['physics_hz'] for t in trace),1)
            stats[role]['median_remote_advanced']=median(sum(g['advanced'] for g in t['remote_groups'].values()) for t in trace)
    result[stage]=stats
print(json.dumps(result,indent=1))
(p/'result.json').write_text(json.dumps(result,indent=2))
