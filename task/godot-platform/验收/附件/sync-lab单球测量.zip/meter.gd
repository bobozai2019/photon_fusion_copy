extends Node

static var previous := 0
static var started := 0
static var empty_time := 0
static var samples := 0
static var elapsed := 0
static var overhead := 0
static var last_print := 0

func _physics_process(_dt: float) -> void:
	var now := Time.get_ticks_usec()
	match process_physics_priority:
		998: previous = now
		999:
			started = now
			empty_time = now - previous
		1001:
			elapsed += now - started
			overhead += empty_time
			samples += 1
			if now - last_print > 480000:
				print("COST_CPU ", roundi(Time.get_unix_time_from_system()*1000), " ", samples, " ", elapsed, " ", overhead)
				last_print = now
				samples = 0
				elapsed = 0
				overhead = 0
