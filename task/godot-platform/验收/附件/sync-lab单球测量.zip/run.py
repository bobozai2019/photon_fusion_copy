from pathlib import Path
from threading import Thread
import sys,subprocess,socket,time,json,shutil,traceback
w=Path(__file__).resolve().parent
examples=w.parents[2]
sys.path.insert(0,str(examples/'tools'))
from verify_sync_lab import configure,LAB
godot=LAB/'runtime/godot-4.6.1/Godot_v4.6.1-stable_win64.exe'
sdk=LAB/'addons/netcode' if sys.argv[1]=='bundled' else examples.parent/'netcode/out/install/win-x64-msvc-mt/Release/godot/addons/netcode'
count=int(sys.argv[2])
project=w/sys.argv[3]
project.mkdir()
configure(project,godot,sdk,'Netcode',False,None)
shutil.copy(w/'meter.gd',project)
for n in ['global','area1','area2']:
    path=project/f'netcode_{n}.tscn'
    s=path.read_text()
    assert s.count('owner_mode = 1')==1
    path.write_text(s.replace('owner_mode = 1','process_physics_priority = 1000\nowner_mode = 1'))
path=project/'lab.gd'
s=path.read_text(encoding='utf-8')
def sub(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new)
sub('func _ready() -> void:', '''var _cost_epoch := 0
func _ready() -> void:
	for priority in [998, 999, 1001]:
		var meter := preload("res://meter.gd").new()
		meter.process_physics_priority = priority
		add_child(meter)''')
sub('	_steps += 1','''	_steps += 1
	if _cost_epoch == 0:
		var file := "res://epoch.txt"
		if _host and not FileAccess.file_exists(file):
			var f := FileAccess.open(file, FileAccess.WRITE)
			f.store_string(str(roundi(Time.get_unix_time_from_system()*1000) + 1500))
			f.close()
		if FileAccess.file_exists(file):
			_cost_epoch = int(FileAccess.get_file_as_string(file))
		if not _cost_epoch: return
	var sec := (roundi(Time.get_unix_time_from_system()*1000) - _cost_epoch) * 0.001
	if sec >= (34.0 if _host else 33.5):
		get_tree().quit()
		return''')
sub('		if writable:\n			var own', '		if writable and ((sec >= 5.0 and sec < 15.0 and _host) or (sec >= 15.0 and sec < 20.0 and not _host) or sec >= 20.0):\n			var own')
sub('			own.publish(_wave, _local_point if _manual else own.deterministic_point(_wave), stamp)','''			if sec < 10.0:
				own.energy = float(_wave)
			else:
				own.publish(_wave, _local_point if _manual else own.deterministic_point(_wave), stamp)''')
sub('	if _host and not _paused and _wave >= LOAD_WARMUP_WAVES:', '	if sec >= 20 and _host and not _paused and _wave >= LOAD_WARMUP_WAVES:')
sub('func _process(dt: float) -> void:', '''func _process(dt: float) -> void:
	if _cost_epoch and roundi(Time.get_unix_time_from_system()*1000) - _cost_epoch >= 34000:
		get_tree().quit()
		return''')
sub('		if _host and _demo_check and _saw_peer:', '		if _host and _demo_check and _saw_peer and sec > 100:')
path.write_text(s,encoding='utf-8')
codes={}
rows=[]
issues=[]
def port():
    with socket.socket() as x:
        x.bind(('127.0.0.1',0));return x.getsockname()[1]
def relay(reader,writer,direction,traffic):
    buffer=bytearray()
    try:
        while chunk:=reader.recv(65536):
            now=time.time_ns()//1_000_000
            writer.sendall(chunk)
            buffer+=chunk
            while len(buffer)>=3:
                size=int.from_bytes(buffer[1:3],'big')
                if len(buffer)<size+3:break
                traffic.append([now,direction,buffer[0],buffer[3:3+size].hex()])
                del buffer[:3+size]
    except (ConnectionResetError,ConnectionAbortedError,BrokenPipeError):pass
    finally:
        if buffer:issues.append('partial frame at close')
        try:writer.shutdown(socket.SHUT_WR)
        except OSError:pass
def proxy(server,hostport):
    try:
        with server.accept()[0] as guest,socket.create_connection(('127.0.0.1',hostport)) as host:
            for x in (guest,host):x.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            t=Thread(target=relay,args=(guest,host,'up',rows));t.start()
            relay(host,guest,'down',rows);t.join()
    except Exception:issues.append(traceback.format_exc())
with socket.socket() as server:
    server.bind(('127.0.0.1',0));server.listen()
    hp=port()
    t=Thread(target=proxy,args=(server,hp),daemon=True);t.start()
    jobs={}
    try:
        for role,ep in [('host',hp),('guest',server.getsockname()[1])]:
            log=(project/f'{role}.log').open('wb')
            cmd=[godot,'--headless','--max-fps','60','--path',project,'--','--backend','Netcode','--objects',str(count),'--endpoint',f'127.0.0.1:{ep}','--demo-check','--trace','--host' if role=='host' else '--join']
            if role=='host':cmd+=['--host-ready',str(project/'ready.txt')]
            jobs[role]=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            log.close()
            if role=='host':
                deadline=time.monotonic()+15
                while not (project/'ready.txt').is_file() and time.monotonic()<deadline and jobs[role].poll() is None:time.sleep(.05)
                assert (project/'ready.txt').read_text().strip()=='ready'
        for role,job in jobs.items():codes[role]=job.wait(timeout=80)
        t.join(3)
    finally:
        for job in jobs.values():
            if job.poll() is None: job.kill();job.wait()
(project/'frames.json').write_text(json.dumps(rows,separators=(',',':')))
summary={'build':(sdk/'build-id.txt').read_text().strip(),'count':count,'exit':codes,'errors':issues,'frames':len(rows)}
for role in jobs:
    txt=(project/f'{role}.log').read_text(encoding='utf-8',errors='replace')
    expected=1 if role=='host' else count-1
    summary[role]=f'SYNC_LAB_FIELDS {expected}/{expected}' in txt and 'SCRIPT ERROR' not in txt
print(json.dumps(summary),flush=True)
assert all(summary[role] for role in jobs) and not any(codes.values()) and not issues
